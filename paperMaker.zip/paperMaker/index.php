<?php 

require_once('database.php');
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PaperMaker | Admin Panel</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
  </head>
  <body>
<div class="wrapper">
  <header>
    <nav class="navbar navbar-inverse navbar-fixed-top" id="myColor">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">PAperMaker</a>
      </div>
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
        <ul class="nav navbar-nav navbar-right">
          <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
          <li><a href="#"><i class="fa fa-power-off"></i> Log Out</a></li>
        </ul>
      </div>
    </div>
</nav>
  </header><!--Header Ends here -->
<div class="clear">
<div class="container-fluid body-section">
  <div class="row">
    <div class="col-md-3">
      <div class="list-group">
        <a href="#" class="list-group-item active">
          <i class="fa fa-tachometer"></i> Dasboard
        </a>
        <a href="index.php" class="list-group-item">
          <span class="badge">20</span>
          <i class="fa fa-file-text-o"></i> All Questions</a>
        <a href="makepaper.php" class="list-group-item">
        <i class="fa fa-file-text-o"></i> Create paper</a>

      </div>
    </div>
    <div class="col-md-9">
        <h1><i class="fa fa-file"></i> Questions <small>View All Questions</small></h1>
        <ol class="breadcrumb">
            <li ><a href="index.html"><i class="fa fa-tachometer"></i> Dashboard</a></li>
            <li class="active"><i class="fa fa-file"></i> Questions</li>
        </ol>
        <div class="row">
          <div class="col-sm-8">
            <form class="" action="index.php" method="post">
              <div class="row">
              <div class="col-md-12">
                    <form class="" action="index.html" method="post">
                    <div class="form-group">
                        <label for="Chapter">Question*</label>
                        <input type="text" required="" name="Question" value="" placeholder="Write your Question here" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">Chapter Name*</label>
                        <input type="text" required="" name="Chapter_name" value="" placeholder="From which Chapter this Question belongs" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">Book*</label>
                        <input type="text" required="" name="Book_name" value="" placeholder="Write the name of Book here...." class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">Rating*</label>
                        <input type="number" required="" name="Rating" value="" placeholder="Rating of this Question beteween 1-5" min="1" max="5" class="form-control">
                    </div>

                    <input type="submit" name="submit" value="Add This Question" class="btn btn-primary">
                    </form>
                </div>
                <!-- <div class="col-xs-8">
                  <input type="submit" name="" value="Apply" class="btn btn-success">
                  <a href="#" class="btn btn-primary">Add New</a>
                </div> -->
              </div>
            </form>
          </div>
        </div>
        <table class="table table-bordered table-striped table-hover">
          <thead>
            <tr>
<!--               <th><input type="checkbox" name="" value=""></th> -->
              <!-- <th>Nu #</th> -->
              <th>Question</th>
              <th>Chapter Name</th>
              <th>Book name</th>
              <th>Rating</th>
<!--               <th>Used</th> -->
            </tr>
          </thead>
          <tbody>

<?php 
$showQuestions = "SELECT * FROM everything";
$resultallQuestions = mysqli_query($conn,$showQuestions);

 while($all_Questions_row = mysqli_fetch_array($resultallQuestions)){
          

          $query_Question     = $all_Questions_row['Question'];
          $query_Chapter      = $all_Questions_row['Chapter'];
          $query_Book         = $all_Questions_row['Book'];
          $query_Rating       = $all_Questions_row['Rating'];
?>

          <tr>
<!--               <td><input type="checkbox" name="" value=""></td>
              <td>1</td> -->
              <td><?php echo $query_Question; ?></td>
              <td><?php echo $query_Chapter; ?></td>
              <td><?php echo $query_Book; ?></td>
              <td><?php echo $query_Rating; ?></td>




            </tr>
<?php }?>



          </tbody>
        </table>
    </div>
  </div>
</div>

<!-- <footer class="text-center">
  Copyright &copy; by <a href="#">Abubakar Shehbaz</a> from 2019
</footer> -->
</div>








































<?php




// Add Question starts


if(ISSET($_POST['submit'])){

    $Questionvar  = $_POST['Question']; // this is the sender's Email address    
    $ChapterName  = $_POST['Chapter_name'];    
    $BookName     = $_POST['Book_name'];    
    $Ratingvar    = $_POST['Rating'];


    $sql = "INSERT INTO everything ( Question,Chapter,Book,Rating,used) VALUES ( 
    '$Questionvar', '$ChapterName','$BookName','$Ratingvar','no')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();


}
// Add Question ends here













// // if condition starts here
// // the message
// $msg = "checking it  2nd \nSecond line of text";

// // use wordwrap() if lines are longer than 70 characters
// $msg = wordwrap($msg,70);

// // send email

// //if condition ends here








flush();
ob_end_flush();
?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>

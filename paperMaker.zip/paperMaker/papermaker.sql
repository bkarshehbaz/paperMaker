-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2019 at 01:17 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `papermaker`
--

-- --------------------------------------------------------

--
-- Table structure for table `everything`
--

CREATE TABLE `everything` (
  `id` int(11) NOT NULL,
  `Question` text NOT NULL,
  `Chapter` text NOT NULL,
  `Book` text NOT NULL,
  `Rating` int(11) NOT NULL,
  `used` text NOT NULL,
  `delete` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `everything`
--

INSERT INTO `everything` (`id`, `Question`, `Chapter`, `Book`, `Rating`, `used`, `delete`) VALUES
(1, '543', '235', '234', 2, 'no', ''),
(2, 'sdaf', 'asdf', 'sdaf', 234, 'no', ''),
(3, 'sdaf', 'asdf', 'sdaf', 234, 'no', ''),
(4, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(5, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(6, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(7, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(8, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(9, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(10, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(11, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(12, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(13, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(14, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(15, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(16, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(17, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(18, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(19, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(20, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(21, 'This is tested ', 'Cahpter name is 1', 'Book number 1', 1, 'no', ''),
(22, 'this is added ', 'chapter 1', 'adf', 5, 'no', ''),
(23, 'this is added ', 'chapter 1', 'adf', 5, 'no', ''),
(24, 'this is added ', 'chapter 1', 'adf', 5, 'no', ''),
(25, 'this is added ', 'chapter 1', 'adf', 5, 'no', ''),
(26, 'this is added ', 'chapter 1', 'adf', 5, 'no', ''),
(27, 'this is added ', 'chapter 1', 'adf', 5, 'no', ''),
(28, 'afd', 'asdf', '234', 234, 'no', ''),
(29, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(30, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(31, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(32, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(33, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(34, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(35, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(36, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(37, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(38, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(39, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(40, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(41, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(42, 'dafas', 'adsf', 'asdf', 423, 'no', ''),
(43, 'This is question number 1', 'Chapter number 1', 'Book number 1', 1, 'no', ''),
(44, 'This is question number 1', 'Chapter number 1', 'Book number 1', 1, 'no', ''),
(45, 'This is question number 1', 'Chapter number 1', 'Book number 1', 1, 'no', ''),
(46, 'This is question number 1', 'Chapter number 1', 'Book number 1', 1, 'no', ''),
(47, 'What is software engineering ?', 'asdfdsa', 'SE 1', 1, 'no', ''),
(48, 'What is software engineering ?', 'asdfdsa', 'SE 1', 1, 'no', ''),
(49, 'What is software engineering ?', 'asdfdsa', 'SE 1', 1, 'no', ''),
(50, '', '', 'adf', 0, 'no', ''),
(51, 'This is final testing', 'chapter 1', 'sc', 1, 'no', ''),
(52, 'this is second question', 'chapter 1', 'sc', 2, 'no', ''),
(53, 'this is second question', 'chapter 1', 'sc', 2, 'no', ''),
(54, 'Thios sfad fasdf ', 'chapter 1 ', 'sc', 4, 'no', ''),
(55, 'sa sadf sadfg sdafg dsg', 'chapter 1', 'sc', 4, 'no', ''),
(56, 'This is chapter 1 rating 5 sc', 'chapter 1', 'sc', 5, 'no', ''),
(57, 'What is software engineering ?', 'chapter 1 ', 'sc', 3, 'no', ''),
(58, 'adding it to test', 'chapter 1', 'sc', 5, 'no', ''),
(59, 'What is wifi', 'chapter 1', 'sc', 3, 'no', ''),
(60, 'What is wifi', 'chapter 1', 'sc', 3, 'no', ''),
(61, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'chapter 1', 'sc', 3, 'no', ''),
(62, 'zzzzzzzzz', 'chapter 1', 'sc', 4, 'no', ''),
(63, 'Testing this last time ', 'chapter 1', 'sc', 3, 'no', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `everything`
--
ALTER TABLE `everything`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `everything`
--
ALTER TABLE `everything`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

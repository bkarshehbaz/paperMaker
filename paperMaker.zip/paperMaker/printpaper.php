<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PaperMaker | Admin Panel</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <style>
        .alert{
            width:760px;
        }
        h4{
            margin-top:10px;
        }
    </style>
</head>
<body style="padding-top:30px;">
    
</body>
</html>
<img src="COMSATS-logo.png" alt="" width="100px" height="100px"  style="margin:0 auto; display:block;"> 
<div class="container" style="margin-buttom:50px;">
        <div class="row">
            <div class="col-md-6">
            Your Name: 
            </div>
            <div class="col-md-6">
            Your Section:
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
            Your Reistration number: 
            </div>
            <div class="col-md-6">
            Subject:
            </div>
        </div>
</div>





<!-- Main if starts here -->
<?php require_once('database.php');




/* Get the all values from here */
    if(isset($_GET["Chapter"]) && isset($_GET["Book_name"]))
    {
        $Book_namE = $_GET["Book_name"];
        $ChapteR = $_GET["Chapter"];

        $totalQuestions = $_GET["totalQuestions"];
        $totalQuestions = intval($totalQuestions);


        $rating1 = $_GET["rating1"];
        $rating1 = intval($rating1);
        
        $rating2 = $_GET["rating2"];
        $rating2 = intval($rating2);
        
        $rating3 = $_GET["rating3"];
        $rating3 = intval($rating3);
        
        $rating4 = $_GET["rating4"];
        $rating4 = intval($rating4);
        
        $rating5 = $_GET["rating5"];
        $rating5 = intval($rating5);

    }
    // echo $Book_namE .'<br>';
    // echo $ChapteR .'<br>';
    // echo $totalQuestions .'<br>';
    
    // echo $rating1 .'<br>';
    // echo $rating2 .'<br>';
    // echo $rating3 .'<br>';
    // echo $rating4 .'<br>';
    // echo $rating5 .'<br>';




$error_message = "Total number of Questions and all other inputs result should be same";

$counter1 = 0;
$counter2 = 0;
$counter3 = 0;
$counter4 = 0;
$counter5 = 0;

// Check if total number of Questions are equal or not 

if($totalQuestions != ($rating1+$rating2+$rating3+$rating4+$rating5) ){
    echo "<div class='alert alert-warning'>
    <strong>Warning!</strong> $error_message.
  </div>";
exit;
}














//################### Rating number 1 lengthy code starts from here  ################################
// If input is zero we don't need this code to run 
if($rating1!= 0){

    $rating_array_1 = [];
    
    $showQuestions            ="SELECT * FROM everything WHERE Rating='1'";
    
    
    $resultallQuestions       = mysqli_query($conn,$showQuestions);

    if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
        
    
    while($all_Questions_row  = mysqli_fetch_array($resultallQuestions)){
        
    //echo "inside of the array loop of 1 ".'<br> ';
        $rating_array_1[]     =    $all_Questions_row['id'];
    
    
        }
    }
    //Total count of Ratings
     $Total_Rating_sql_1 = count($rating_array_1);
    
    // echo "Total number of array is 1 = ".$Total_Rating_sql_1.'<br>';
    //echo $Total_Rating_sql_1;
    if(($Total_Rating_sql_1) >= $rating1 ){
    
        $showQuestions = "SELECT * FROM everything Where Chapter='$ChapteR' AND Book='$Book_namE' AND Rating='1' LIMIT $rating1";
        $resultallQuestions = mysqli_query($conn,$showQuestions);
        
        if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
         while($all_Questions_row = mysqli_fetch_array($resultallQuestions)){
                  
        
                  $query_Question     = $all_Questions_row['Question'];
                  $query_Chapter      = $all_Questions_row['Chapter'];
                  $query_Book         = $all_Questions_row['Book'];
                  $query_Rating       = $all_Questions_row['Rating'];
    
                  echo '<h4><strong>Q. </strong>'.$query_Question.'</h4>' ;
         }  }
    
    
    
    }
    else{
        echo "<div class='alert alert-warning'>
        <strong>Warning!</strong> There are no enough Questions of Rating 1 in this Chapter or Book.
      </div>";
      exit;
    }
    
    
    }
    // Input sould't be zero








//################### Rating number 2 lengthy code starts from here  ################################
// If input is zero we don't need this code to run 
if($rating2!= 0){

    $rating_array_2 = [];
    
    $showQuestions            ="SELECT * FROM everything WHERE Rating='2'";
    
    
    $resultallQuestions       = mysqli_query($conn,$showQuestions);

    if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
        
    
    while($all_Questions_row  = mysqli_fetch_array($resultallQuestions)){
        
    //echo "inside of the array loop of 2 ".'<br> ';
        $rating_array_2[]     =    $all_Questions_row['id'];
    
    
        }
    }
    //Total count of Ratings
     $Total_Rating_sql_2 = count($rating_array_2);
    
     //echo "Total number of array is 2 = ".$Total_Rating_sql_2.'<br>';
    //echo $Total_Rating_sql_1;
    if(($Total_Rating_sql_2) >= $rating2 ){
    
        $showQuestions = "SELECT * FROM everything Where Chapter='$ChapteR' AND Book='$Book_namE' AND Rating='2' LIMIT $rating2";
        $resultallQuestions = mysqli_query($conn,$showQuestions);
        
        if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
         while($all_Questions_row = mysqli_fetch_array($resultallQuestions)){
                  
        
                  $query_Question     = $all_Questions_row['Question'];
                  $query_Chapter      = $all_Questions_row['Chapter'];
                  $query_Book         = $all_Questions_row['Book'];
                  $query_Rating       = $all_Questions_row['Rating'];
    
                  echo '<h4><strong>Q. </strong>'.$query_Question.'</h4>' ;
         }  }
    
    
    
    }
    else{
        echo "<div class='alert alert-warning'>
        <strong>Warning!</strong> There are no enough Questions of Rating 2 in this Chapter or Book.
      </div>";
      exit;
    }
    
    
    }
    // Input sould't be zero







//################### Rating number 3 lengthy code starts from here  ################################
// If input is zero we don't need this code to run 
if($rating3!= 0){

    $rating_array_3 = [];
    
    $showQuestions            ="SELECT * FROM everything WHERE Rating='3'";
    
    
    $resultallQuestions       = mysqli_query($conn,$showQuestions);

    if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
        
    
    while($all_Questions_row  = mysqli_fetch_array($resultallQuestions)){
        
    //echo "inside of the array loop of 3 ".'<br> ';
        $rating_array_3[]     =    $all_Questions_row['id'];
    
    
        }
    }
    //Total count of Ratings
     $Total_Rating_sql_3 = count($rating_array_3);
    
    // echo "Total number of array is = ".$Total_Rating_sql_3.'<br>';
    //echo $Total_Rating_sql_1;
    if(($Total_Rating_sql_3) >= $rating3 ){
        $showQuestions = "SELECT * FROM everything Where Chapter='$ChapteR' AND Book='$Book_namE' AND Rating='3' LIMIT $rating3";
        $resultallQuestions = mysqli_query($conn,$showQuestions);
        
        if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
         while($all_Questions_row = mysqli_fetch_array($resultallQuestions)){
                  
        
                  $query_Question     = $all_Questions_row['Question'];
                  $query_Chapter      = $all_Questions_row['Chapter'];
                  $query_Book         = $all_Questions_row['Book'];
                  $query_Rating       = $all_Questions_row['Rating'];
    
                  echo '<h4><strong>Q. </strong>'.$query_Question.'</h4>' ;
         }  }
    
    
    
    }
    else{
        echo "<div class='alert alert-warning'>
        <strong>Warning!</strong> There are no enough Questions of Rating 3 in this Chapter or Book.
      </div>";
      exit;
    }
    
    
    }
    // Input sould't be zero




//################### Rating number 4 lengthy code starts from here  ################################
// If input is zero we don't need this code to run 
if($rating4!= 0){

    $rating_array_4 = [];
    
    $showQuestions            ="SELECT * FROM everything WHERE Rating='4'";
    
    
    $resultallQuestions       = mysqli_query($conn,$showQuestions);

    if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
        
    
    while($all_Questions_row  = mysqli_fetch_array($resultallQuestions)){
        

        $rating_array_4[]     =    $all_Questions_row['id'];
        //echo "inside of the array loop of 4 =".$all_Questions_row['id'].'<br> ';
    
        }
    }
    //Total count of Ratings
     $Total_Rating_sql_4 = count($rating_array_4);
    
     //echo "Total number of array in 4 is= ".$Total_Rating_sql_4.'<br>';
    //echo $Total_Rating_sql_1;
    if($Total_Rating_sql_4 >= $rating4 ){
        $showQuestions = "SELECT * FROM everything Where Chapter='$ChapteR' AND Book='$Book_namE' AND Rating='4' LIMIT $rating4";
        $resultallQuestions = mysqli_query($conn,$showQuestions);
        
        if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
         while($all_Questions_row = mysqli_fetch_array($resultallQuestions)){
                  
        
                  $query_Question     = $all_Questions_row['Question'];
                  $query_Chapter      = $all_Questions_row['Chapter'];
                  $query_Book         = $all_Questions_row['Book'];
                  $query_Rating       = $all_Questions_row['Rating'];
    
                  echo '<h4><strong>Q. </strong>'.$query_Question.'</h4>' ;
         }  }
    }
    else{
        echo "<div class='alert alert-warning'>
        <strong>Warning!</strong> There are no enough Questions of Rating 4 in this Chapter or Book.
      </div>";
      exit;
    }
    
    
    }
    // Input sould't be zero




//################### Rating number 5 lengthy code starts from here  ################################
// If input is zero we don't need this code to run 
if($rating5!= 0){

    $rating_array_5 = [];
    
    $showQuestions            ="SELECT * FROM everything WHERE Rating='5'";
    
    
    $resultallQuestions       = mysqli_query($conn,$showQuestions);

    if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
        
    
    while($all_Questions_row  = mysqli_fetch_array($resultallQuestions)){
        
    //echo "inside of the array loop of 5 ".'<br> ';
        $rating_array_5[]     =    $all_Questions_row['id'];
    
    
        }
    }
    //Total count of Ratings
     $Total_Rating_sql_5 = count($rating_array_5);
    
     //echo "Total number of array is 5 = ".$Total_Rating_sql_5.'<br>';
    //echo $Total_Rating_sql_1;
    if(($Total_Rating_sql_5) >= $rating5 ){
    
        $showQuestions = "SELECT * FROM everything Where Chapter='$ChapteR' AND Book='$Book_namE' AND Rating='5' LIMIT $rating5";
        $resultallQuestions = mysqli_query($conn,$showQuestions);
        
        if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
         while($all_Questions_row = mysqli_fetch_array($resultallQuestions)){
                  
        
                  $query_Question     = $all_Questions_row['Question'];
                  $query_Chapter      = $all_Questions_row['Chapter'];
                  $query_Book         = $all_Questions_row['Book'];
                  $query_Rating       = $all_Questions_row['Rating'];
    
                  echo '<h4><strong>Q. </strong>'.$query_Question.'</h4>' ;
         }  }
    
    
    
    }
    else{
        echo "<div class='alert alert-warning'>
        <strong>Warning!</strong> There are no enough Questions of Rating 5 in this Chapter or Book.
      </div>";
      exit;
    }
    
    
    }
    // Input sould't be zero


?>
<!-- Main if ends here -->















































































        <table class="table table-bordered table-striped table-hover">
          <thead>
            <tr>
<!--               <th><input type="checkbox" name="" value=""></th> -->
              <!-- <th>Nu #</th> -->
              <!-- <th>Question</th>
              <th>Chapter Name</th>
              <th>Book name</th>
              <th>Rating</th> -->
<!--               <th>Used</th> -->
            </tr>
          </thead>
          <tbody>

<?php 
$showQuestions = "SELECT * FROM everything Where Chapter='$ChapteR' AND Book='$Book_namE' ";
$resultallQuestions = mysqli_query($conn,$showQuestions);

if($all_Questions_row     = mysqli_num_rows($resultallQuestions) > 0){
 while($all_Questions_row = mysqli_fetch_array($resultallQuestions)){
          

          $query_Question     = $all_Questions_row['Question'];
          $query_Chapter      = $all_Questions_row['Chapter'];
          $query_Book         = $all_Questions_row['Book'];
          $query_Rating       = $all_Questions_row['Rating'];
?>

          <tr>
<!--               <td><input type="checkbox" name="" value=""></td>
              <td>1</td> -->
              <!-- <td><?php echo $query_Question; ?></td>
              <td><?php echo $query_Chapter; ?></td>
              <td><?php echo $query_Book; ?></td>
              <td><?php echo $query_Rating; ?></a> -->
            </tr>
<?php } }?>



          </tbody>
        </table>
<?php 

require_once('database.php');

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PaperMaker | Admin Panel</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
  </head>
  <body>
<div class="wrapper">
  <header>
    <nav class="navbar navbar-inverse navbar-fixed-top" id="myColor">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">PAperMaker</a>
      </div>
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
        <ul class="nav navbar-nav navbar-right">
          <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
          <li><a href="#"><i class="fa fa-power-off"></i> Log Out</a></li>
        </ul>
      </div>
    </div>
</nav>
  </header><!--Header Ends here -->
<div class="clear">
<div class="container-fluid body-section">
  <div class="row">
    <!-- <div class="col-md-3">
      <div class="list-group">
        <a href="#" class="list-group-item active">
          <i class="fa fa-tachometer"></i> Dasboard
        </a>
        <a href="#" class="list-group-item">
          <span class="badge">10</span>
          <i class="fa fa-file-text-o"></i> All Questions</a>
        <a href="#" class="list-group-item"><span class="badge">4</span>
        <i class="fa fa-folder-open"></i> All Chapters</a>

      </div>
    </div> -->
    <div class="col-md-12">
        <h1><i class="fa fa-file"></i> Make paper <small>make unique papers as many you want</small></h1>
        <ol class="breadcrumb">
            <li ><a href="index.html"><i class="fa fa-tachometer"></i> Dashboard</a></li>
            <li class="active"><i class="fa fa-file"></i> Questions</li>
        </ol>
        <div class="row">
          <div class="col-sm-8">
            <form class="" action="printpaper.php" method="get">
              <div class="row">
              <div class="col-md-12">
                    <form class="" action="" method="">
                    <div class="form-group">
                        <label for="Chapter">Book*</label>
                        <input type="text" required="" name="Book_name" value="" placeholder="From which Chapter this Question belongs" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">Chapter*</label>
                        <input type="text" required="" name="Chapter" value="" placeholder="write your number here" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">Total Number of Questions*</label>
                        <input type="number" required="" name="totalQuestions" min="1" value="" placeholder="write your number here" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">How many Question do you want from Rating 1*</label>
                        <input type="number" required="" name="rating1" value="" placeholder="write your number here" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">How many Question do you want from Rating 2*</label>
                        <input type="number" required="" name="rating2" value="" placeholder="write your number here" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">How many Question do you want from Rating 3*</label>
                        <input type="number" required="" name="rating3" value="" placeholder="write your number here" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">How many Question do you want from Rating 4*</label>
                        <input type="number" required="" name="rating4" value="" placeholder="write your number here" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="Chapter">How many Question do you want from Rating 5*</label>
                        <input type="number" required="" name="rating5" value="" placeholder="write your number here" class="form-control">
                    </div>



                    <input type="submit" name="submit" value="Create Paper" class="btn btn-primary btns">
                    </form>
                </div>
                <!-- <div class="col-xs-8">
                  <input type="submit" name="" value="Apply" class="btn btn-success">
                  <a href="#" class="btn btn-primary">Add New</a>
                </div> -->
              </div>
            </form>



          </div>
        </div>
<!--  -->
    </div>
  </div>
</div>

<!-- <footer class="text-center">
  Copyright &copy; by <a href="#">Abubakar Shehbaz</a> from 2019
</footer> -->
</div>








































<?php




// // Add Question starts


// if(ISSET($_POST['submit'])){

//     $Chaptervar  = $_POST['Chapter']; // this is the sender's Email address    
//     $BookName     = $_POST['Book_name'];    


//     $chapterwise       = "SELECT  * FROM everything WHERE Chapter = '$Chaptervar'";

// $chapterwiseResults    = mysqli_query($conn,$chapterwise);


//  while($chapterwiseRow = mysqli_fetch_array($chapterwiseResults)){

//  		$query_Question     =    $chapterwiseRow['Question'];


// echo $query_Question ."<br>";

//  }


// // if ($conn->query($sql) === TRUE) {
// //     echo "New record created successfully";
// // } else {
// //     echo "Error: " . $sql . "<br>" . $conn->error;
// // }

// $conn->close();




// }
// Add Question ends here













// // if condition starts here
// // the message
// $msg = "checking it  2nd \nSecond line of text";

// // use wordwrap() if lines are longer than 70 characters
// $msg = wordwrap($msg,70);

// // send email

// //if condition ends here








flush();
ob_end_flush();
?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
